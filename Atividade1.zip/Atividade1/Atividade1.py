import sqlite3
banco= sqlite3.connect('BancoDeDados.db')
cursor= banco.cursor()


def create_table(cursor):
     cursor.execute(""" 
        CREATE TABLE if not exists funcionarios(
            id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            nome VARCHAR(45)NOT NULL,
            idade nome VARCHAR(3)NOT NULL,
            cpf VARCHAR(11)NOT NULL,
            endereco VARCHAR(100)NOT NULL);
        """)
     print('Tabela criada com sucesso.')

def menu ():
    while True:
        print("--------------------------------")
        print("--------------MENU--------------")
        print("--------------------------------")
        print(" (1) - Cadastrar funcionário")
        print(" (2) - Atualizar funcionário")
        print(" (3) - Remover funcionário")
        print(" (4) - Visualizar funcionário")
        print(" (5) - SAIR")
        print("")
        opcao = input("ESCOLHA A OPÇÃO: ")
        
        if opcao =='1':
             CadastraFuncionario(banco,cursor)
        elif opcao=='2':
            AtualizarFuncionario(banco,cursor)
        elif opcao=='3':
            DeletarFuncionario(banco,cursor)
        elif opcao=='4':
            VisualizarFuncionario(cursor)
        elif opcao =='5':
            break
        else:
             print("Opção Inválida!")

#(1)CADASTRA FUNCIONÁRIO
def CadastraFuncionario(banco, cursor):
        NomeFuncionario=str(input("Digite o seu nome completo: "))
        IdadeFuncionario=int(input("Digite sua idade: "))
        NumeroCPF=str(input("Digite seu CPF: "))
        print("Abaixo digite o seu endereço")
        rua=str(input("Digite o nome da sua rua: "))
        bairro=str(input("Digite seu bairro: "))
        NunCasa=int(input("Digite o número da sua casa: "))
        EnderecoFuncionario=(f"{rua},{bairro}, N°{NunCasa}")
        try:
            cursor.execute("""
            INSERT INTO funcionarios (nome, idade, cpf,endereco)
            VALUES (?, ?, ?, ?)
            """, (NomeFuncionario, IdadeFuncionario, NumeroCPF, EnderecoFuncionario))
            banco.commit()
            print('Funcionário(a) Salvo com Sucesso.')
        except sqlite3.IntegrityError:
            print(f"Erro: Essa'{NumeroCPF}' já existe!.")
             
        print("---------------------------------------")
        print("PARABENS VOCÊ CADASTROU FUNCIONÁRIO!!!")
        print("")

#(2)ATUALIZAR DADOS DO FUNCIONÁRIO
def AtualizarFuncionario(banco, cursor):
    try:
        id_funcionario = int(
            input("Informe o ID do Funcionário(a) para atualizar o Nome: "))
        novo_nome = input("Informe o novo Nome: ")
        cursor.execute("""
          UPDATE funcionarios
          SET nome = ?
          WHERE id = ?
          """, (novo_nome, id_funcionario))
        banco.commit()
        if cursor.rowcount > 0:
            print('Atualizado com sucesso.')
        else:
            print(
                f"Não foi encontrado Funcionário(a) com o ID: {id_funcionario}")
    except ValueError:
        print("Entrada inválida. Verifique o número para o ID.")
        
#DELETAR FUNCIONÁRIO 
def DeletarFuncionario(banco,cursor):
    try:
        id_funcionario = int(
            input("Informe o ID do funcionário para excluir: "))
        cursor.execute("""
          DELETE FROM funcionarios
          WHERE id = ?
          """, (id_funcionario,))
        banco.commit()
        if cursor.rowcount > 0:
            print('Registro excluído com sucesso.')
        else:
            print(f"Não foi encontrado funcionário com o ID: {id_funcionario}")
    except ValueError:
        print("Entrada inválida. Verifique o número para o ID.")

#(4)MOSTRAR LISTA DE FUNCIONÁRIOS
def VisualizarFuncionario(cursor):
    cursor.execute("""
     SELECT * FROM funcionarios;
     """)
    linhas = cursor.fetchall()
    if linhas:
        print("Lista de Funcionários(as):")
        for linha in linhas:
            print(
                f"ID: {linha[0]}, Nome: {linha[1]}, Idade: {linha[2]}, CPF: {linha[3]}, Endereço: {linha[4]}")
    else:
        print("Não há Funcionários(as) Cadastrados!")
    return linhas

create_table(cursor)
menu()
banco.close()
       
             




    

