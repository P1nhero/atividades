dict_produtos = [
    {'1':{"nome": "arroz", "preço": 0.22}}
    {'2':{"nome": "feijão", "preço": 2.55}}
    {'3':{"nome": "azeite", "preço": 6.23}}
    {'4':{"nome": "macarrão", "preço": 44.2}}
    {'5':{"nome": "ração", "preço": 98}}
    ]

lista_produtos=[]
while(True):
    codigo = input("Digite o código: ")
    lista_produtos.append(dict_produtos[codigo])
    print(dict_produtos [codigo] ["nome"])

    print(lista_produtos)