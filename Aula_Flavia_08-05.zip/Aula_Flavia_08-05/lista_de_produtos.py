def MENU():
    while True:
         #MENU
        print('-------'*4)
        print("-----TABELA DE PREÇOS------")
        print("     (1) ARROZ = 0,20")
        print("     (2) FEIJÃO = 2,55")
        print("     (3) AZEITE = 6,23")
        print("     (4) MACARRÃO = 44,2")
        print("     (5) RAÇÃO = 98,0")
        print('-------'*4)

        #Entrada de dados do usuario
        codigo = int(input("Digite o codigo do produto: "))
        quant_produto = int(input("Digite a quantidade de produtos: "))
        
        print("ESCOLHA A OPÇÃO")
        print("(1) Adicionar mais itens a compra")
        print("(2) Finalizar a compra")
        opcao = input("OPÇÃO = ")

        if opcao == '1':
            return 
        elif opcao =='2':
            break
        else:
            print("Opção Inválida! Tente ovamente")



        #lista de produtos
        preco_produto = [0.20, 2.55, 6.23, 44.2, 98]
        produtos_nome = ["Arroz", "Feijão", "Azeite", "Macarrão", "Ração"]
        #calculo
        preco_total=quant_produto*preco_produto[codigo -1]

        #Resultado
        print(f"Preço = R$ {preco_total:.2f}")

MENU()
        

