#MENU
print('-------'*4)
print("-----TABELA DE PREÇOS------")
print("     (1) ARROZ = 0,20")
print("     (2) FEIJÃO = 2,55")
print("     (3) AZEITE = 6,23")
print("     (4) MACARRÃO = 44,2")
print("     (5) RAÇÃO = 98,0")
print('-------'*4)

#Entrada de dados do usuario
codigo = int(input("Digite o codigo do produto: "))
quant_produto = int(input("Digite a quantidade de produto: "))
#lista de produtos
preco_produto = [0.20, 2.55, 6.23, 44.2, 98]

preco_total=quant_produto*preco_produto[codigo -1]
#Resultado
print(f"Preço = R$ {preco_total:.2f}")

