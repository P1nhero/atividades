def MENU():
    preco_produto =0
    produto = [0.20, 2.55, 6.23, 44.2, 98]
    
    while True:
        #MENU
        print('-------'*4)
        print("-----TABELA DE PREÇOS------")
        print("     (1) ARROZ = 0,20")
        print("     (2) FEIJÃO = 2,55")
        print("     (3) AZEITE = 6,23")
        print("     (4) MACARRÃO = 44,2")
        print("     (5) RAÇÃO = 98,0")
        print('-------'*4)

        #Entrada de dados do usuario
        codigo = int(input("Digite o codigo do produto: "))
        if (codigo <= len(produto)):
            quant_produto = int(input("Digite a quantidade de produtos: "))
            preco_produto=quant_produto*produto[codigo -1]
            #Resultado
            print(f"Preço = R$ {preco_produto:.2f}")
        
            
            print("(1) Adicionar mais itens a compra")
            print("(2) Finalizar a compra")
            print("ESCOLHA A OPÇÃO")
            opcao = input("OPÇÃO = ")
            if opcao =='1':
                print("Ok")
            if opcao =='2':
                break
        else:
            print("Opção Inválida! Tente Novamente")
        

MENU()
        

