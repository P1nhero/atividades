#Calcular dimençaõ do terreno

print("Informe a dimençaõ do terreno")
y = float(input("digite a altura do terreno: "))
x = float(input("digite a largura do terreno: "))

print(f"Dimenção do terreno é de {x} X {y}")

A = x*y

print("A área do terro é igual ", A)