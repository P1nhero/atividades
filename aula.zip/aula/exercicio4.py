funcionarios=5
for i in range(funcionarios):
    print("----------------------------------------------------------------------")
    print("ABAIXO DIGTE O VALOR DO SEU SALÁRIO ATUAL")

    SalarioInicial=float(input("Digite seu salário: "))
    Aumento= (SalarioInicial*15/100)
    NovoSalario= SalarioInicial+Aumento
    Desconto= (NovoSalario*8/100)
    Salarioatual=NovoSalario-Desconto
    print("----------------------------------------------------------------------")
    print(f"O seu salário inicial era de R${float(SalarioInicial)}")
    print(f"Seu salário com o aumento de 15% fica R${float(NovoSalario)}")
    print(f"E com o deconto de 8% de imposto o seu salário fianl é de R${float(Salarioatual)}"),