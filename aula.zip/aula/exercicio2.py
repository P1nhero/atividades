
l=[0,0,0,0,0,0]
h=[0,0,0,0,0,0]
t=[0,0,0,0,0,0]
lados =5

for i in range(lados):
    l[i] = float(input(f"L"str
    
    ))


