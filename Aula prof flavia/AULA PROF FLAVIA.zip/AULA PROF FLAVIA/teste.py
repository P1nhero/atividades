import sqlite3

conn = sqlite3.connect('funcionarios.db')
cursor = conn.cursor()

def  creat_table(cursor):
     cursor.execute(""" CREATE TABLE funcionarios(
                    id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    nome VARCHAR(45)NOT NULL,
                    matricula VARCHAR(10) NOT NULL,
                    salario REAL);
                    """)

def insert(cursor, nome, matricula, salario):
     cursor.execute("""INSERT INTO funcionarios (nome, matricula,salario)
     VALUES('{nome}', {matricula}, '{salario}')
     """.format(nome = nome, matricula = matricula, salario =salario))
     conn.commit
     print('Dados inseridos com sucesso')

def select_data_all():
     cursor.execute("""
     SELECT * FROM funcionarios;
     """)
     return cursor.fetchall()
creat_table(cursor)
num_funcionario = int(input("Digite o numero de funcionarios: "))

for i in range(num_funcionario):
     print("---Funcionario(a)"+str(i+1)+"---")
     nome = input("Digite seu nome: ")
     matricula = input("Digite sua matricula")
     salario = float(input("Digite seu salario"))
     insert(cursor,nome,matricula,salario)


print("---")
print("{tnome}{tmatricula}{tsalario}".format(tnome = "NOME".ljust(10), tmatricula = "MATRICULA".ljust(10), tsalario = "SALARIO".ljust(10)))

linhas = select_data_all()

for linha in linhas:
     print("{nome}{matricula}{salario}".format(nome = linha[1].ljust(10), matricula = linha[2].ljust(10), salario = linha[3]))


